44.1 kHz, 16-bit
All sounds Recorded and edited by Whitney Schramm.
SchrammAudio.com